# Christian CLI Toolkit for Termux

A powerful Christian command-line application for Termux with Bible verses, prayer journal, daily devotionals, and more.

## Features

| Feature | Description |
|---------|-------------|
| **Verse of the Day** | Daily Bible verse based on the date |
| **Random Verse** | Get a random Bible verse anytime |
| **Search Verses** | Search by keyword (faith, love, fear, etc.) |
| **Bible Books** | Reference list of all 66 books |
| **Prayer Journal** | Add, list, and track prayer requests |
| **Answered Prayers** | Mark prayers as answered |
| **Daily Devotional** | Daily reading with theme, verse, and reflection |
| **Christian Quotes** | Inspirational quotes from Christian leaders |
| **Salvation Prayer** | Guide for receiving Christ |

## Data Storage

All data is stored in shared storage so you can edit it in **Acode** too:

```
~/storage/shared/Coding/christian-app/data/
```

- `bible_verses.txt` — Add your favorite verses
- `devotionals.txt` — Write your own devotionals
- `christian_quotes.txt` — Add inspirational quotes
- `prayer_journal.txt` — Your prayer requests (auto-managed)

## Setup in Termux

```bash
# 1. Make sure storage is set up
termux-setup-storage

# 2. Navigate to the app
cd ~/storage/shared/Coding/christian-app

# 3. Run setup
bash setup-christian-app.sh

# 4. Launch the app
./christian-cli.sh
```

## Open in Acode

1. Open Acode
2. Open folder: `/storage/emulated/0/Coding/christian-app/`
3. Edit verses, devotionals, or quotes — changes appear instantly in Termux

## File Format

**bible_verses.txt** — Each line: `Reference|Verse text`
```
John 3:16|For God so loved the world that he gave his one and only Son...
```

**devotionals.txt** — Each line: `Day|Title|Verse Reference|Content`
```
Day 1|Trusting God's Plan|Jeremiah 29:11|God has good plans for your life...
```

**christian_quotes.txt** — Each line: `"Quote" — Author`
```
"Faith is taking the first step..." — Martin Luther King Jr.
```

## Prayer Journal Format

Each line: `DATE|REQUEST|STATUS`
- `STATUS` can be `pending` or `answered`

## Author

Christian Life Developer — Obadiah Koech  
GitHub: https://github.com/koechoba  
Email: koechobadia003@gmail.com

> "I can do all things through Christ who strengthens me." — Philippians 4:13
