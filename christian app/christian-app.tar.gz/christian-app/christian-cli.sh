#!/system/bin/sh
# christian-cli.sh — Powerful Christian CLI toolkit for Termux
# Run inside Termux: ./christian-cli.sh
#
# Features:
#   - Bible verse of the day & search
#   - Prayer journal (add, list, read, mark answered)
#   - Daily devotional readings
#   - Worship & praise tools
#   - Christian quotes
#   - Salvation prayer & discipleship resources
#   - Bible book reference
#
# Data is stored in shared storage so Acode can also edit it.

set -eu

APP_DIR="$HOME/storage/shared/Coding/christian-app"
DATA_DIR="$APP_DIR/data"
JOURNAL_FILE="$DATA_DIR/prayer_journal.txt"
VERSES_FILE="$DATA_DIR/bible_verses.txt"
DEVOTIONAL_FILE="$DATA_DIR/devotionals.txt"
QUOTES_FILE="$DATA_DIR/christian_quotes.txt"

# ---------------------------------------------------------------------------
# Colors (ANSI)
# ---------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ---------------------------------------------------------------------------
# Initialize data files if missing
# ---------------------------------------------------------------------------
init_data() {
  mkdir -p "$DATA_DIR"

  if [ ! -f "$VERSES_FILE" ]; then
    cat > "$VERSES_FILE" << 'EOF'
John 3:16|For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.
Philippians 4:13|I can do all this through him who gives me strength.
Jeremiah 29:11|For I know the plans I have for you, declares the LORD, plans to prosper you and not to harm you, plans to give you hope and a future.
Psalm 23:1|The LORD is my shepherd, I lack nothing.
Proverbs 3:5-6|Trust in the LORD with all your heart and lean not on your own understanding; in all your ways submit to him, and he will make your paths straight.
Romans 8:28|And we know that in all things God works for the good of those who love him, who have been called according to his purpose.
Matthew 6:33|But seek first his kingdom and his righteousness, and all these things will be given to you as well.
Isaiah 41:10|So do not fear, for I am with you; do not be dismayed, for I am your God. I will strengthen you and help you.
Psalm 46:1|God is our refuge and strength, an ever-present help in trouble.
Joshua 1:9|Have I not commanded you? Be strong and courageous. Do not be afraid; do not be discouraged, for the LORD your God will be with you wherever you go.
Philippians 4:6-7|Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God. And the peace of God, which transcends all understanding, will guard your hearts and your minds in Christ Jesus.
1 Peter 5:7|Cast all your anxiety on him because he cares for you.
Psalm 37:4|Take delight in the LORD, and he will give you the desires of your heart.
Ephesians 2:8-9|For it is by grace you have been saved, through faith—and this is not from yourselves, it is the gift of God—not by works, so that no one can boast.
Galatians 5:22-23|But the fruit of the Spirit is love, joy, peace, forbearance, kindness, goodness, faithfulness, gentleness and self-control.
Romans 12:2|Do not conform to the pattern of this world, but be transformed by the renewing of your mind.
2 Timothy 1:7|For the Spirit God gave us does not make us timid, but gives us power, love and self-discipline.
Hebrews 11:1|Now faith is confidence in what we hope for and assurance about what we do not see.
Psalm 119:105|Your word is a lamp for my feet, a light on my path.
1 John 4:18|There is no fear in love. But perfect love drives out fear, because fear has to do with punishment.
EOF
  fi

  if [ ! -f "$DEVOTIONAL_FILE" ]; then
    cat > "$DEVOTIONAL_FILE" << 'EOF'
Day 1|Trusting God's Plan|Jeremiah 29:11|God has good plans for your life. Even when you cannot see the way forward, trust that He is working everything for your good. Surrender your worries to Him today.
Day 2|The Power of Prayer|Philippians 4:6-7|Prayer is your direct line to God. Bring every anxiety, every need, every joy to Him. His peace will guard your heart.
Day 3|Walking in Faith|2 Corinthians 5:7|We walk by faith, not by sight. Faith means trusting God even when the path isn't clear. Take one step today in obedience.
Day 4|God's Unfailing Love|Romans 8:38-39|Nothing can separate you from God's love. Not height, not depth, not anything in all creation. You are deeply loved.
Day 5|Strength in Weakness|2 Corinthians 12:9|God's power is made perfect in weakness. When you feel weak, His strength shines through. Rest in Him today.
Day 6|Forgiveness|Colossians 3:13|Forgive as the Lord forgave you. Holding onto bitterness only hurts you. Release it to God.
Day 7|The Great Commission|Matthew 28:19-20|Go and make disciples of all nations. Share the love of Christ with someone today.
EOF
  fi

  if [ ! -f "$QUOTES_FILE" ]; then
    cat > "$QUOTES_FILE" << 'EOF'
"Faith is taking the first step even when you don't see the whole staircase." — Martin Luther King Jr.
"God never said that the journey would be easy, but He did say that the arrival would be worthwhile." — Max Lucado
"Worry does not empty tomorrow of its sorrow; it empties today of its strength." — Corrie ten Boom
"To be a Christian without prayer is no more possible than to be alive without breathing." — Martin Luther
"The will of God will never take you where the grace of God cannot keep you." — Unknown
"God is most glorified in us when we are most satisfied in Him." — John Piper
"Your life is the only Bible some people will ever read." — Unknown
EOF
  fi

  if [ ! -f "$JOURNAL_FILE" ]; then
    cat > "$JOURNAL_FILE" << 'EOF'
# Prayer Journal
# Format: DATE|PRAYER REQUEST|STATUS (pending|answered)
# Lines starting with # are comments.
2026-01-01|Example prayer request: Guidance in decision making|pending
EOF
  fi
}

# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------
header() {
  clear
  echo "${CYAN}${BOLD}"
  echo "  ____  _             ____                  _"
  echo " / ___|| |_ _   _ ___|  _ \ _   _ _ __ ___ | |__"
  echo " \___ \| __| | | / __| |_) | | | | '_ \ _ \| '_ \"
  echo "  ___) | |_| |_| \__ \  __/| |_| | | | | | | |_) |"
  echo " |____/ \__|\__,_|___/_|    \__,_|_| |_| |_|_.__/"
  echo "${NC}"
  echo "${GREEN}${BOLD}      Christian Life Developer CLI Toolkit${NC}"
  echo "${BLUE}      ------------------------------------${NC}"
  echo ""
}

pause() {
  echo ""
  echo "${YELLOW}Press Enter to continue...${NC}"
  read -r _
}

# ---------------------------------------------------------------------------
# Bible verse functions
# ---------------------------------------------------------------------------
verse_of_the_day() {
  init_data
  # Pick a verse based on the day of year
  DAY_OF_YEAR=$(date +%j)
  TOTAL=$(wc -l < "$VERSES_FILE")
  # Remove comments/count only real verses
  LINES=$(grep -v '^#' "$VERSES_FILE" | wc -l)
  INDEX=$(( (DAY_OF_YEAR % LINES) + 1 ))
  VERSE=$(grep -v '^#' "$VERSES_FILE" | sed -n "${INDEX}p")
  REF=$(echo "$VERSE" | cut -d'|' -f1)
  TEXT=$(echo "$VERSE" | cut -d'|' -f2-)

  echo "${CYAN}${BOLD}=== Verse of the Day ===${NC}"
  echo ""
  echo "${YELLOW}$REF${NC}"
  echo ""
  echo "$TEXT"
  echo ""
  echo "${BLUE}---$(date '+%Y-%m-%d')---${NC}"
}

random_verse() {
  init_data
  LINES=$(grep -v '^#' "$VERSES_FILE" | wc -l)
  RAND=$(( (RANDOM % LINES) + 1 ))
  VERSE=$(grep -v '^#' "$VERSES_FILE" | sed -n "${RAND}p")
  REF=$(echo "$VERSE" | cut -d'|' -f1)
  TEXT=$(echo "$VERSE" | cut -d'|' -f2-)

  echo "${CYAN}${BOLD}=== Random Bible Verse ===${NC}"
  echo ""
  echo "${YELLOW}$REF${NC}"
  echo ""
  echo "$TEXT"
  echo ""
}

search_verse() {
  init_data
  echo "${CYAN}${BOLD}=== Search Bible Verses ===${NC}"
  echo ""
  echo "Enter keyword to search (e.g. 'faith', 'love', 'fear'):"
  read -r KEYWORD
  echo ""
  echo "${YELLOW}Results for '$KEYWORD':${NC}"
  echo ""
  FOUND=0
  while IFS='|' read -r REF TEXT; do
    # Skip comments
    case "$REF" in \#*) continue ;; esac
    COMBINED="$REF $TEXT"
    if echo "$COMBINED" | grep -qi "$KEYWORD"; then
      echo "${GREEN}$REF${NC}"
      echo "  $TEXT"
      echo ""
      FOUND=1
    fi
  done < "$VERSES_FILE"
  if [ "$FOUND" -eq 0 ]; then
    echo "${RED}No verses found matching '$KEYWORD'.${NC}"
  fi
}

list_bible_books() {
  echo "${CYAN}${BOLD}=== Books of the Bible ===${NC}"
  echo ""
  echo "${BLUE}Old Testament:${NC}"
  echo "Genesis, Exodus, Leviticus, Numbers, Deuteronomy, Joshua, Judges, Ruth,"
  echo "1 Samuel, 2 Samuel, 1 Kings, 2 Kings, 1 Chronicles, 2 Chronicles, Ezra,"
  echo "Nehemiah, Esther, Job, Psalms, Proverbs, Ecclesiastes, Song of Solomon,"
  echo "Isaiah, Jeremiah, Lamentations, Ezekiel, Daniel, Hosea, Joel, Amos,"
  echo "Obadiah, Jonah, Micah, Nahum, Habakkuk, Zephaniah, Haggai, Zechariah, Malachi"
  echo ""
  echo "${BLUE}New Testament:${NC}"
  echo "Matthew, Mark, Luke, John, Acts, Romans, 1 Corinthians, 2 Corinthians,"
  echo "Galatians, Ephesians, Philippians, Colossians, 1 Thessalonians, 2 Thessalonians,"
  echo "1 Timothy, 2 Timothy, Titus, Philemon, Hebrews, James, 1 Peter, 2 Peter,"
  echo "1 John, 2 John, 3 John, Jude, Revelation"
  echo ""
}

# ---------------------------------------------------------------------------
# Prayer journal functions
# ---------------------------------------------------------------------------
add_prayer() {
  init_data
  echo "${CYAN}${BOLD}=== Add Prayer Request ===${NC}"
  echo ""
  echo "Enter your prayer request:"
  read -r REQUEST
  if [ -z "$REQUEST" ]; then
    echo "${RED}Request cannot be empty.${NC}"
    return
  fi
  DATE=$(date '+%Y-%m-%d')
  echo "$DATE|$REQUEST|pending" >> "$JOURNAL_FILE"
  echo ""
  echo "${GREEN}Prayer request added!${NC}"
  echo "Date: $DATE"
  echo "Request: $REQUEST"
  echo ""
  echo "${BLUE}Remember: 'Cast all your anxiety on him because he cares for you.' (1 Peter 5:7)${NC}"
}

list_prayers() {
  init_data
  echo "${CYAN}${BOLD}=== Prayer Journal ===${NC}"
  echo ""
  if [ ! -s "$JOURNAL_FILE" ] || [ "$(grep -v '^#' "$JOURNAL_FILE" | wc -l)" -eq 0 ]; then
    echo "${YELLOW}No prayer requests yet. Add one with option 5.${NC}"
    return
  fi
  echo "${BLUE}Pending requests:${NC}"
  echo ""
  NUM=1
  while IFS='|' read -r DATE REQUEST STATUS; do
    case "$DATE" in \#*) continue ;; esac
    if [ "$STATUS" = "pending" ]; then
      echo "${YELLOW}$NUM.${NC} [$DATE] $REQUEST"
      NUM=$((NUM + 1))
    fi
  done < "$JOURNAL_FILE"
  echo ""
  echo "${GREEN}Answered prayers:${NC}"
  echo ""
  NUM=1
  while IFS='|' read -r DATE REQUEST STATUS; do
    case "$DATE" in \#*) continue ;; esac
    if [ "$STATUS" = "answered" ]; then
      echo "${GREEN}$NUM.${NC} [$DATE] $REQUEST ${BLUE}[Answered!]${NC}"
      NUM=$((NUM + 1))
    fi
  done < "$JOURNAL_FILE"
  echo ""
}

mark_answered() {
  init_data
  echo "${CYAN}${BOLD}=== Mark Prayer as Answered ===${NC}"
  echo ""
  # Show pending prayers
  COUNT=0
  while IFS='|' read -r DATE REQUEST STATUS; do
    case "$DATE" in \#*) continue ;; esac
    if [ "$STATUS" = "pending" ]; then
      COUNT=$((COUNT + 1))
      echo "${YELLOW}$COUNT.${NC} [$DATE] $REQUEST"
    fi
  done < "$JOURNAL_FILE"
  echo ""
  if [ "$COUNT" -eq 0 ]; then
    echo "${YELLOW}No pending prayers to mark.${NC}"
    return
  fi
  echo "Enter the number of the prayer that was answered:"
  read -r PRAYER_NUM
  if ! echo "$PRAYER_NUM" | grep -qE '^[0-9]+$'; then
    echo "${RED}Invalid number.${NC}"
    return
  fi
  # Rewrite the file, marking the selected pending prayer as answered
  TMP_FILE="$DATA_DIR/.journal_tmp"
  CURRENT=0
  while IFS='|' read -r DATE REQUEST STATUS; do
    case "$DATE" in \#*)
      echo "$DATE|$REQUEST|$STATUS" >> "$TMP_FILE"
      continue
      ;;
    esac
    if [ "$STATUS" = "pending" ]; then
      CURRENT=$((CURRENT + 1))
      if [ "$CURRENT" -eq "$PRAYER_NUM" ]; then
        STATUS="answered"
      fi
    fi
    echo "$DATE|$REQUEST|$STATUS" >> "$TMP_FILE"
  done < "$JOURNAL_FILE"
  mv "$TMP_FILE" "$JOURNAL_FILE"
  echo "${GREEN}Prayer marked as answered! Praise God!${NC}"
}

# ---------------------------------------------------------------------------
# Devotional functions
# ---------------------------------------------------------------------------
daily_devotional() {
  init_data
  DAY_OF_YEAR=$(date +%j)
  LINES=$(grep -v '^#' "$DEVOTIONAL_FILE" | wc -l)
  INDEX=$(( (DAY_OF_YEAR % LINES) + 1 ))
  DEVO=$(grep -v '^#' "$DEVOTIONAL_FILE" | sed -n "${INDEX}p")
  TITLE=$(echo "$DEVO" | cut -d'|' -f1)
  THEME=$(echo "$DEVO" | cut -d'|' -f2)
  VERSE_REF=$(echo "$DEVO" | cut -d'|' -f3)
  CONTENT=$(echo "$DEVO" | cut -d'|' -f4-)

  echo "${CYAN}${BOLD}=== Daily Devotional ===${NC}"
  echo ""
  echo "${YELLOW}$TITLE${NC}"
  echo "${BLUE}Theme: $THEME${NC}"
  echo "${MAGENTA}Verse: $VERSE_REF${NC}"
  echo ""
  echo "$CONTENT"
  echo ""
  echo "${BLUE}---$(date '+%Y-%m-%d')---${NC}"
}

# ---------------------------------------------------------------------------
# Quotes
# ---------------------------------------------------------------------------
random_quote() {
  init_data
  LINES=$(grep -v '^#' "$QUOTES_FILE" | wc -l)
  RAND=$(( (RANDOM % LINES) + 1 ))
  QUOTE=$(grep -v '^#' "$QUOTES_FILE" | sed -n "${RAND}p")

  echo "${CYAN}${BOLD}=== Christian Quote ===${NC}"
  echo ""
  echo "${MAGENTA}\"$QUOTE\"${NC}"
  echo ""
}

# ---------------------------------------------------------------------------
# Salvation / discipleship
# ---------------------------------------------------------------------------
salvation_prayer() {
  echo "${CYAN}${BOLD}=== Prayer of Salvation ===${NC}"
  echo ""
  echo "${GREEN}If you would like to receive Jesus Christ as your Lord and Savior,${NC}"
  echo "you can pray this prayer from your heart:"
  echo ""
  echo "${YELLOW}'Dear Lord Jesus,${NC}"
  echo "${YELLOW}I believe You are the Son of God and that You died for my sins.${NC}"
  echo "${YELLOW}I repent of my sins and turn to You.${NC}"
  echo "${YELLOW}Come into my heart, be my Lord and Savior.${NC}"
  echo "${YELLOW}I receive Your forgiveness and eternal life.${NC}"
  echo "${YELLOW}Thank You for saving me. In Jesus' name, Amen.'${NC}"
  echo ""
  echo "${GREEN}If you prayed this prayer, you are now a child of God!${NC}"
  echo "${BLUE}John 1:12 - 'Yet to all who did receive him, to those who believed in his name,${NC}"
  echo "${BLUE}he gave the right to become children of God.'${NC}"
  echo ""
  echo "${CYAN}Next steps:${NC}"
  echo "1. Tell someone about your decision"
  echo "2. Start reading the Bible (begin with the Gospel of John)"
  echo "3. Pray every day"
  echo "4. Find a Bible-believing church to attend"
  echo ""
}

# ---------------------------------------------------------------------------
# Main menu
# ---------------------------------------------------------------------------
main_menu() {
  while true; do
    header
    echo "${BOLD}Main Menu:${NC}"
    echo ""
    echo "${GREEN}1.${NC}  Verse of the Day"
    echo "${GREEN}2.${NC}  Random Bible Verse"
    echo "${GREEN}3.${NC}  Search Bible Verses"
    echo "${GREEN}4.${NC}  List Books of the Bible"
    echo "${GREEN}5.${NC}  Add Prayer Request"
    echo "${GREEN}6.${NC}  View Prayer Journal"
    echo "${GREEN}7.${NC}  Mark Prayer as Answered"
    echo "${GREEN}8.${NC}  Daily Devotional"
    echo "${GREEN}9.${NC}  Christian Quote"
    echo "${GREEN}10.${NC} Prayer of Salvation"
    echo "${GREEN}0.${NC}  Exit"
    echo ""
    echo -n "${BOLD}Choose an option: ${NC}"
    read -r CHOICE

    case "$CHOICE" in
      1) verse_of_the_day; pause ;;
      2) random_verse; pause ;;
      3) search_verse; pause ;;
      4) list_bible_books; pause ;;
      5) add_prayer; pause ;;
      6) list_prayers; pause ;;
      7) mark_answered; pause ;;
      8) daily_devotional; pause ;;
      9) random_quote; pause ;;
      10) salvation_prayer; pause ;;
      0) echo ""; echo "${GREEN}God bless you!${NC}"; exit 0 ;;
      *) echo "${RED}Invalid option.${NC}"; sleep 1 ;;
    esac
  done
}

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
init_data
main_menu
