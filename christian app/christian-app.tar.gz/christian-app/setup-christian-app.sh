#!/system/bin/sh
# setup-christian-app.sh — Install and run the Christian CLI in Termux
#
# Usage: bash setup-christian-app.sh

set -e

echo "========================================"
echo "  Christian CLI Setup for Termux"
echo "========================================"
echo ""

APP_DIR="$HOME/storage/shared/Coding/christian-app"

echo "==> Making scripts executable..."
chmod +x "$APP_DIR/christian-cli.sh"

echo "==> Creating symlink in home directory..."
ln -sf "$APP_DIR" "$HOME/christian-app"

echo "==> Done!"
echo ""
echo "To run the Christian CLI:"
echo "  cd ~/christian-app"
echo "  ./christian-cli.sh"
echo ""
echo "Or from anywhere:"
echo "  ~/christian-app/christian-cli.sh"
echo ""
echo "Data files (prayer journal, verses, etc.) are stored in:"
echo "  ~/storage/shared/Coding/christian-app/data/"
echo ""
echo "You can also edit these files in Acode at:"
echo "  /storage/emulated/0/Coding/christian-app/"
echo ""
echo "${BOLD}God bless your journey in faith!${NC}"
